import collections
import numpy as np
from collections import namedtuple
from random import random, uniform, choice, randrange, sample,randint
import torch
from torch import optim
import torch.nn as nn
from torch.nn import functional as F
from ue import UE


device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
Transition = namedtuple('Transition',
                        ('state', 'action', 'next_state', 'reward'))  # Define a transition tuple

class ReplayMemory(object):    # Define a replay memory

    def __init__(self, capacity):
        self.capacity = capacity
        self.memory = []
        self.position = 0

    def Push(self, *args):
        if len(self.memory) < self.capacity:
            self.memory.append(None)
        self.memory[self.position] = Transition(*args)
        self.position = (self.position + 1) % self.capacity

    def Sample(self, batch_size):
        print(sample(self.memory, batch_size))
        return sample(self.memory, batch_size)

    def __len__(self):
        return len(self.memory)

class DQN(nn.Module):
    def __init__(self, n_actions, n_inputs, lr=0.01):
        super(DQN, self).__init__()
        self.fc1 = nn.Linear(n_inputs, 64)
        self.fc2 = nn.Linear(64, 32)
        self.fc3 = nn.Linear(32, n_actions)
        self.optimizer = optim.Adam(self.parameters(), lr=lr)
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.loss = nn.MSELoss()

    def forward(self, state):
        x = F.relu(self.fc1(state.to(torch.float32)))
        x = F.relu(self.fc2(x))
        actions = self.fc3(x)
        return actions


class UAV:
    def __init__(self, sce,opt,state,index, epsilon=0.9):
        self.UAV_action = 7
        self.sce = sce
        self.opt = opt
        self.epsilon = epsilon
        self.state = state
        self.device = device
        self.memory = ReplayMemory(opt.capacity)
        self.model_policy = DQN(self.UAV_action,3)
        self.model_target = DQN(self.UAV_action,3)
        self.model_target.load_state_dict(self.model_policy.state_dict())
        self.model_target.eval()
        self.optimizer = optim.RMSprop(params=self.model_policy.parameters(), lr=opt.learningrate,
                                       momentum=opt.momentum)

    def Select_Action(self, state,epsilon):  # 选择动作
        if np.random.random() < epsilon:
            # with torch.no_grad():
            Q_value = self.model_policy(torch.tensor([state], dtype=torch.float32).to(device))
            action = torch.argmax(Q_value).item()
        else:
            action = randint(0,6)
        return action

    def change_state(self,action,state):
        if action == 0:
            state[1] = state[1]+50
        elif action == 1:
            state[1] = state[1]-50
        elif action == 2:
            state[0] = state[0]-50
        elif action == 3:
            state[0] = state[0]+50
        elif action == 4:
            state[2] = state[2]+2
        elif action == 5:
            state[2] = state[2]-2
        elif action == 6:  # 以uav为判断条件
            return state
        return state

    def Save_Transition(self, state, action, next_state, reward):  # +
        action = torch.tensor([action])
        reward = torch.tensor([reward])
        state = torch.from_numpy(state)
        next_state = torch.from_numpy(next_state)
        state = state.unsqueeze(0)
        next_state = next_state.unsqueeze(0)
        self.memory.Push(state, action, next_state, reward)

    def Target_Update(self):  # Update the parameters of the target network
        self.model_target.load_state_dict(self.model_policy.state_dict())

    def Optimize_Model(self):
        if len(self.memory) < self.opt.batch_size:
            return
        transitions = self.memory.Sample(self.opt.batch_size)
        batch = Transition(*zip(*transitions))
        non_final_mask = torch.tensor(tuple(map(lambda s: s is not None,
                                                batch.next_state)), dtype=torch.bool)
        non_final_next_states = torch.cat([s for s in batch.next_state
                                           if s is not None])
        state_batch = torch.cat(batch.state).type(torch.int64)
        action_batch = torch.cat(batch.action).type(torch.int64)
        reward_batch = torch.cat(batch.reward).type(torch.int64)
        print(state_batch,"\n",action_batch)
        state_action_values = self.model_policy(state_batch).gather(-1, action_batch)
        next_state_values = torch.zeros(self.opt.batch_size)
        print(non_final_next_states)
        next_action_batch = torch.unsqueeze(self.model_policy(non_final_next_states).max(1)[1], -1)
        next_state_values = self.model_target(non_final_next_states).gather(-1, next_action_batch)
        expected_state_action_values = (next_state_values * self.opt.gamma) + reward_batch.unsqueeze(1)
        # Compute Huber loss
        loss = F.smooth_l1_loss(state_action_values, expected_state_action_values)  # Double DQN
        next_state_values[non_final_mask] = self.model_target(non_final_next_states).max(1)[0].detach()  # DQN
        expected_state_action_values = (next_state_values * self.gamma) + reward_batch
        # Compute Huber loss
        loss = F.smooth_l1_loss(state_action_values, expected_state_action_values.unsqueeze(1))
        # Optimize the model
        self.optimizer.zero_grad()
        loss.backward()
        for param in self.model_policy.parameters():
            param.grad.data.clamp_(-1, 1)
        self.optimizer.step()